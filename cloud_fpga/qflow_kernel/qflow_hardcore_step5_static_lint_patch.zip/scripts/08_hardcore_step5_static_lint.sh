#!/usr/bin/env bash
set -euo pipefail

echo "[QFlow local hardening step 5] Static lint / elaboration / generic synthesis checks"
ROOT="$(pwd)"
echo "Repo subdir: $ROOT"

mkdir -p results/lint_static
LOGDIR="results/lint_static"
SNAP="results/evidence_snapshot_06_static_lint_pass"
rm -rf "$SNAP"

# --------------------------------------------------------------------
# 0. Regenerate the fixed-seed vector set and generated testbench.
# --------------------------------------------------------------------
if [ -f sw/generate_randomized_golden_vectors.py ]; then
  python3 sw/generate_randomized_golden_vectors.py \
    --deterministic-out vectors/golden_vectors.csv \
    --exp-lut-out vectors/exp_lut.hex \
    --random-count 200 \
    --seed 20260514 | tee "$LOGDIR/vector_generation.log"
else
  python3 sw/generate_golden_vectors.py | tee "$LOGDIR/vector_generation.log"
fi

python3 sw/generate_tb_from_vectors.py | tee "$LOGDIR/testbench_generation.log"

RTL_FILES="rtl/fdpe_kernel.v rtl/skag_weight_kernel.v rtl/path_selector_kernel.v rtl/qflow_cloud_kernel.v"
TB_FILE="tb/tb_qflow_cloud_kernel.v"

# --------------------------------------------------------------------
# 1. Icarus strict-ish compile/elaboration check with -Wall.
#    This catches syntax/elaboration problems in the same simulator flow.
# --------------------------------------------------------------------
echo "[1/5] Icarus Verilog compile/elaboration with -Wall"
set +e
iverilog -g2012 -Wall -o "$LOGDIR/iverilog_wall_tb.out" "$TB_FILE" $RTL_FILES \
  > "$LOGDIR/iverilog_wall.log" 2>&1
IVERILOG_RC=$?
set -e

cat "$LOGDIR/iverilog_wall.log"

if [ "$IVERILOG_RC" -ne 0 ]; then
  echo "STEP 5 FAIL: iverilog -Wall compile failed."
  exit 1
fi

if grep -Eiq "(error|syntax error|unable to bind|cannot|failed)" "$LOGDIR/iverilog_wall.log"; then
  echo "STEP 5 FAIL: fatal/error-like message found in iverilog log."
  exit 1
fi

IVERILOG_WARNINGS=$(grep -Ei "warning" "$LOGDIR/iverilog_wall.log" | wc -l | tr -d ' ')
echo "Icarus warning count: $IVERILOG_WARNINGS" | tee "$LOGDIR/iverilog_warning_count.txt"

# --------------------------------------------------------------------
# 2. Re-run full simulation and Python comparison.
# --------------------------------------------------------------------
echo "[2/5] Full simulation and golden comparison"
vvp "$LOGDIR/iverilog_wall_tb.out" | tee "$LOGDIR/static_lint_sim_output.txt"

grep -q "ALL TESTS PASS" "$LOGDIR/static_lint_sim_output.txt"

python3 sw/compare_hw_vs_golden.py \
  --golden vectors/golden_vectors.csv \
  --hw results/hardware_output.csv \
  --out "$LOGDIR/static_lint_hardware_vs_python.csv" | tee "$LOGDIR/static_lint_compare.log"

grep -q "FAIL=0" "$LOGDIR/static_lint_compare.log"

# --------------------------------------------------------------------
# 3. Optional Verilator lint-only check.
#    If Verilator is unavailable, record SKIP rather than failing.
# --------------------------------------------------------------------
echo "[3/5] Verilator lint-only check if available"
if command -v verilator >/dev/null 2>&1; then
  set +e
  verilator --lint-only -Wall --timing --top-module qflow_cloud_kernel $RTL_FILES \
    > "$LOGDIR/verilator_lint.log" 2>&1
  VERILATOR_RC=$?
  set -e
  cat "$LOGDIR/verilator_lint.log"

  if [ "$VERILATOR_RC" -ne 0 ]; then
    echo "STEP 5 FAIL: Verilator lint returned non-zero."
    exit 1
  fi

  if grep -Eiq "%Error|syntax error|Unsupported|Internal Error" "$LOGDIR/verilator_lint.log"; then
    echo "STEP 5 FAIL: Verilator error-like message found."
    exit 1
  fi
  echo "VERILATOR_LINT=PASS" | tee "$LOGDIR/verilator_status.txt"
else
  echo "VERILATOR_LINT=SKIP_NOT_INSTALLED" | tee "$LOGDIR/verilator_status.txt"
fi

# --------------------------------------------------------------------
# 4. Optional Yosys generic synthesis/elaboration check.
#    This does not replace AWS Vivado. It only catches unsynthesizable RTL.
# --------------------------------------------------------------------
echo "[4/5] Yosys generic synthesis check if available"
if command -v yosys >/dev/null 2>&1; then
  cat > "$LOGDIR/yosys_qflow_kernel.ys" <<'YOSYS'
read_verilog -sv rtl/fdpe_kernel.v rtl/skag_weight_kernel.v rtl/path_selector_kernel.v rtl/qflow_cloud_kernel.v
hierarchy -check -top qflow_cloud_kernel
proc
opt
fsm
opt
memory -nomap
opt
stat
check
write_json results/lint_static/qflow_cloud_kernel_yosys.json
YOSYS

  set +e
  yosys -q -s "$LOGDIR/yosys_qflow_kernel.ys" > "$LOGDIR/yosys_synth.log" 2>&1
  YOSYS_RC=$?
  set -e
  cat "$LOGDIR/yosys_synth.log"

  if [ "$YOSYS_RC" -ne 0 ]; then
    echo "STEP 5 FAIL: Yosys synthesis/elaboration returned non-zero."
    exit 1
  fi

  if grep -Eiq "(ERROR|syntax error|Latch inferred|multiple conflicting drivers|unresolved)" "$LOGDIR/yosys_synth.log"; then
    echo "STEP 5 FAIL: Yosys error-like or unsafe message found."
    exit 1
  fi
  echo "YOSYS_GENERIC_SYNTH=PASS" | tee "$LOGDIR/yosys_status.txt"
else
  echo "YOSYS_GENERIC_SYNTH=SKIP_NOT_INSTALLED" | tee "$LOGDIR/yosys_status.txt"
fi

# --------------------------------------------------------------------
# 5. Audit generated CSVs for row count, PASS count, and latency stability.
# --------------------------------------------------------------------
echo "[5/5] CSV evidence audit"
python3 - <<'PY'
from pathlib import Path
import pandas as pd

golden = pd.read_csv("vectors/golden_vectors.csv")
hw = pd.read_csv("results/hardware_output.csv")
cmp = pd.read_csv("results/lint_static/static_lint_hardware_vs_python.csv")

errors = []
if len(golden) != len(hw):
    errors.append(f"golden/hardware row mismatch: {len(golden)} vs {len(hw)}")
if len(cmp) != len(golden):
    errors.append(f"compare/golden row mismatch: {len(cmp)} vs {len(golden)}")
if "pass" in cmp.columns:
    pass_values = cmp["pass"].astype(str).str.upper()
    if not (pass_values == "PASS").all():
        errors.append("not all compare rows are PASS")
elif "result" in cmp.columns:
    pass_values = cmp["result"].astype(str).str.upper()
    if not (pass_values == "PASS").all():
        errors.append("not all compare rows are PASS")
else:
    # If compare script schema changes, fall back to checking no FAIL text later in shell.
    pass

lat = sorted(hw["latency_cycles"].dropna().astype(int).unique().tolist()) if "latency_cycles" in hw.columns else []
if lat != [2]:
    errors.append(f"latency not stable at [2], observed {lat}")

if errors:
    print("STATIC LINT AUDIT FAIL")
    for e in errors:
        print(" -", e)
    raise SystemExit(1)

print("STATIC LINT AUDIT PASS")
print(f"Golden vectors: {len(golden)}")
print(f"Hardware rows: {len(hw)}")
print(f"Compare rows: {len(cmp)}")
print(f"Latency cycles observed: {lat}")
PY

mkdir -p "$SNAP"
cp "$LOGDIR"/*.log "$SNAP"/ 2>/dev/null || true
cp "$LOGDIR"/*.txt "$SNAP"/ 2>/dev/null || true
cp "$LOGDIR"/static_lint_hardware_vs_python.csv "$SNAP"/
cp "$LOGDIR"/static_lint_sim_output.txt "$SNAP"/
cp vectors/golden_vectors.csv "$SNAP"/
cp vectors/exp_lut.hex "$SNAP"/
cp results/hardware_output.csv "$SNAP"/
[ -f "$LOGDIR/qflow_cloud_kernel_yosys.json" ] && cp "$LOGDIR/qflow_cloud_kernel_yosys.json" "$SNAP"/ || true

VERILATOR_STATUS="$(cat "$LOGDIR/verilator_status.txt" 2>/dev/null || echo VERILATOR_LINT=UNKNOWN)"
YOSYS_STATUS="$(cat "$LOGDIR/yosys_status.txt" 2>/dev/null || echo YOSYS_GENERIC_SYNTH=UNKNOWN)"

cat > "$SNAP/README.md" <<EOF
# QFlow Cloud FPGA Kernel — Evidence Snapshot 06

This snapshot records Hardcore Local Check Step 5 before AWS EC2 F2 launch.

## Result

- Fixed-seed vector dataset regenerated: 215 vectors expected
- Icarus Verilog compile/elaboration with \`-Wall\`: PASS
- Icarus warning count: ${IVERILOG_WARNINGS}
- RTL simulation: PASS
- Hardware-output CSV vs Python golden CSV: PASS
- ${VERILATOR_STATUS}
- ${YOSYS_STATUS}
- Latency cycles observed in transaction rows: [2]

## Coverage purpose

This step checks static compile/elaboration cleanliness, optional Verilator lint, optional Yosys generic synthesis/elaboration, and the same hardware-vs-golden agreement after the stricter static checks.

## Claim boundary

This is still local RTL simulation/static-tool evidence only. It is not AWS F2 physical FPGA execution evidence yet. Yosys generic synthesis is not a substitute for the AWS Vivado/HDK AFI build.
EOF

echo "Snapshot written: $SNAP"
echo "STEP 5 PASS: static lint/elaboration/generic-synthesis local gate is clean."
