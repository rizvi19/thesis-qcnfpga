# QFlow AWS F2 Cloud-FPGA Starter Package

This package is the first local preparation layer for the `cloud-fpga-f2-kernel` branch of the QFlow thesis repository. It is designed to reduce AWS cost by making the small QFlow cloud kernel pass locally before launching an F2 instance.

## What this package contains

```text
cloud_fpga/qflow_kernel/
  rtl/
    fdpe_kernel.v
    skag_weight_kernel.v
    path_selector_kernel.v
    qflow_cloud_kernel.v
  tb/
    tb_qflow_cloud_kernel.v
  sw/
    generate_golden_vectors.py
    generate_tb_from_vectors.py
    compare_hw_vs_golden.py
  vectors/
    exp_lut.hex
    golden_vectors.csv
  docs/
    kernel_spec.md
  scripts/
    00_git_branch_setup.sh
    01_run_local_sim.sh
    02_aws_first_session_checklist.sh
    03_aws_qflow_build_commands.sh
  Makefile
```

## Repository branch workflow

From your QFlow repo root:

```bash
cd /media/shahriar-rizvi/Data/CSE/Thesis/from13March/qflow_step1_phase0

git status
git checkout -b cloud-fpga-f2-kernel
mkdir -p cloud_fpga/qflow_kernel/{rtl,tb,sw,vectors,results,docs,scripts}
```

Copy the `cloud_fpga/qflow_kernel` folder from this package into your repo, then run:

```bash
cd cloud_fpga/qflow_kernel
make all
```

If `iverilog` is missing:

```bash
sudo apt update
sudo apt install -y iverilog
```

Commit after local PASS:

```bash
git add cloud_fpga/qflow_kernel
git commit -m "Add AWS F2 QFlow cloud kernel starter"
git push -u origin cloud-fpga-f2-kernel
```

## Minimum-cost rule

Do not open AWS F2 until `make all` passes locally. The first paid AWS session should only run the official AWS HDK example. The second paid session should integrate the QFlow kernel.

## Current limitation

This package was generated in a sandbox that does not have Icarus Verilog installed, so I could not execute the Verilog simulation here. The files include a Makefile and scripts so you can run the local pass gate on your Linux machine.
